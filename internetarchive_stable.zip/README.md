**Screenshot:**

![Screenshot](/Screenshots/1.png)


**Features:**

* Stream Videos from Archive.org
* Save Your Favorite Archives to 'My Favorites'.


**How to Install (Official Plugin Repository):**

1) Navigate to Movian/M7 > Settings > General > Alternative Plugin Repository URL:

2) Set this value to 'https://bit.ly/streamprom7'

3) Return to Movian/M7 Home Screen.

4) Navigate to Plugins > Browse Available Plugins > Video Streaming > Archive.org

5) Select Install (Plugin will now update automatically).

6) Return to Movian/M7 Home Screen and Enjoy!


![Stable-Release plugin.zip Download (Latest Version)](/internetarchive_stable.zip?raw=true)

![Pre-Release plugin.zip (May Contain Bugs)](/internetarchive.zip?raw=true)


**Available Languages:**

* English


